library(ismev)
library(evd)
library(evgam)

HSBC <- read.csv("C:/Users/BVBDo/Desktop/R code/HSBC M.csv", header = TRUE, sep = ",")
BCS  <- read.csv("C:/Users/BVBDo/Desktop/R code/BCS.csv", header = TRUE, sep = ",")

#prices
PHSBC <- HSBC$Open
PBCS  <- BCS$Open

#Dates
HSBCDates <- HSBC$Date
HSBCDates <- as.Date(c(HSBCDates),format="%Y-%m-%d")
BCSDates  <- BCS$Date
BCSDates  <- as.Date(c(BCSDates),format="%Y-%m-%d") 
plot(HSBCDates,PHSBC)
plot(BCSDates,PBCS)

HSBCR<--(PHSBC[1:(length(PHSBC)-1)]-PHSBC[2:(length(PHSBC))])/PHSBC[2:(length(PHSBC))]
HSBCDates<-HSBCDates[-length(HSBCDates)]
plot(HSBCDates,HSBCR)
BCSR<--(PBCS[1:(length(PBCS)-1)]-PBCS[2:(length(PBCS))])/PBCS[2:(length(PBCS))]
BCSDates<-BCSDates[-length(BCSDates)]
plot(BCSDates,BCSR)

#To get contemporaneous series
AllDates<-intersect(HSBCDates,BCSDates)
AllDates<-as.POSIXct(AllDates*24*60*60,origin = "1970-01-01")
AllDates<-as.Date(AllDates,format="%Y-%m-%d %H:%M:%S")
is.element(HSBCDates[1],AllDates)

date.logic<-function(date1,dates2)
{
  is.element(date1,dates2)
}

# check
sum(sapply(HSBCDates,date.logic,dates2=AllDates))

Banks<-cbind(HSBCR[sapply(HSBCDates,date.logic,dates2=AllDates)],BCSR[sapply(BCSDates,date.logic,dates2=AllDates)])

dim(Banks)
plot(Banks[,1:2])

#Pairwise plots
par(mar=c(4,6,2,2))
pdf("BanksHSBC-BCS pairwise plots.pdf")
par(mar=c(5,6,2,0.5))
plot(Banks[,1:2], xlab=expression(Y[HSBC]),ylab=expression(Y[BCS]),cex.axis=2,cex.lab=2,pch=20)
dev.off()

source("C:/Users/BVBDo/Desktop/6161177/ModelDiagnosticsNewNames.r")
#2-dim Chis
chiPlot(data=Banks, ylabel=expression(chi[HLRB]~(q)), chimod=NULL, nsim=1000, nq = 35, qmin = 0.5, qmax = 0.99)

# Initially transform and fit on standardized scale. NB code for standardized data is written on standard Pareto scale (exponential
# of standard exponential scale), but works exactly the same as if it were on standard exponential scale.

x<-Banks

# Use empirical probability integral transform to put on uniform scale

u1<-unif(x=x[,1])
hist(u1)

u2<-unif(x=x[,2])
hist(u2)

# Transform to standard Pareto scale

xpb<-cbind(1/(1-u1),1/(1-u2))

# Create matrix of data on MVP scale (at least one threshold exc)
# (exponential of Y_E-u_E|Y_E \not\leq u_E)

logic<-xpb[,1]>quantile(xpb[,1],0.77)|xpb[,2]>quantile(xpb[,2],0.77)
xpb2<-cbind(xpb[logic,1]/quantile(xpb[,1],0.77),xpb[logic,2]/quantile(xpb[,2],0.77))
plot(log(xpb2))
dim(xpb2)

# exponential margins
xeb2<-log(xpb2)


# Same but on MGPD scale (i.e. scale of the observations)

Banks2<-cbind(Banks[logic,1]-quantile(Banks[,1],0.77),Banks[logic,2]-quantile(Banks[,2],0.77))
plot(Banks2)
dim(Banks2)

# Initially examine "most complex" dependence models to home in on best family of models
########################################################################################
source("C:/Users/BVBDo/Desktop/6161177/CommonFunctions.r")
source("C:/Users/BVBDo/Desktop/6161177/Gumbel_T_Functions.r")
source("C:/Users/BVBDo/Desktop/6161177/MVGaussian_T_Functions.r")
source("C:/Users/BVBDo/Desktop/6161177/RevExp_T_Functions.r")
source("C:/Users/BVBDo/Desktop/6161177/RevExp_U_Functions.r")
source("C:/Users/BVBDo/Desktop/6161177/Gumbel_U_Functions.r")

# h_T based on the Gumbel

fit1<-fit.MGPD.GumbelT(x=xeb2, u=rep(0,2), std=T, dep.scale.fix=F, maxit=2000)
fit1
fit1<-fit.MGPD.GumbelT(x=xeb2, u=rep(0,2), std=T, dep.scale.fix=F, maxit=2000, dep.start=fit1$mle)
fit1

fit1.1<-fit.MGPD.GumbelT(x=xeb2, u=rep(0,2), std=T, dep.scale.fix=T, maxit=2000)
fit1.1
fit1.1<-fit.MGPD.GumbelT(x=xeb2, u=rep(0,2), std=T, dep.scale.fix=T, maxit=2000,dep.start=fit1.1$mle)
fit1.1

library(mvtnorm)
library(Matrix)


# h_U based on the Gumbel

fit2<-fit.MGPD.GumbelU(x=xeb2, u=rep(0,2), std=T, dep.scale.fix=F)
fit2
fit2<-fit.MGPD.GumbelU(x=xeb2, u=rep(0,2), std=T, dep.scale.fix=F, dep.start=fit2$mle, maxit=2000)
fit2

fit2.1<-fit.MGPD.GumbelU(x=xeb2, u=rep(0,2), std=T, dep.scale.fix=T)
fit2.1
fit2.1<-fit.MGPD.GumbelU(x=xeb2, u=rep(0,2), std=T, dep.scale.fix=T,dep.start = fit2.1$mle)
fit2.1

# Minimized log-likelihoods and AICs for most complicated models

fit1$nll
fit2$nll


fit1$nll+2*length(fit1$mle)
fit2$nll+2*length(fit2$mle)


# h_U based on the Gumbel
fit2
fit2.1

# compute likelihood ratio test here

# Further parameterizations of this model

# Free scale parameter, constrained location parameters
fit2.2<-fit.MGPD.GumbelU(x=xeb2, u=rep(0,2), std=T, dep.scale.fix=F, dep.loc.fix=T)
fit2.2
fit2.2<-fit.MGPD.GumbelU(x=xeb2, u=rep(0,2), std=T, dep.scale.fix=F, dep.loc.fix=T, dep.start = fit2.2$mle)
fit2.2

# Single scale parameter, fixed location
fit2.3<-fit.MGPD.GumbelU(x=xeb2, u=rep(0,2), std=T, dep.scale.fix=T, dep.loc.fix=T)
fit2.3
fit2.3<-fit.MGPD.GumbelU(x=xeb2, u=rep(0,2), std=T, dep.scale.fix=T, dep.loc.fix=T, dep.start = fit2.3$mle)
fit2.3

#likelihood ratio test here

# Final model: fit1.5 (Single dependence parameter, combined marginal shape, different marginal scale)

# With Hessian, to get standard errors
fit2.4<-fit.MGPD.GumbelU(x=Banks2, u=rep(0,2), std=F,
                         dep.scale.fix=T, dep.loc.fix=T, marg.shape.ind=1:2, marg.scale.ind=1:2,
                         dep.start=fit2.3$mle[1],maxit=5000)
fit2.4

fit2.4<-fit.MGPD.GumbelU(x=Banks2, u=rep(0,2), std=F,
                         dep.scale.fix=T, dep.loc.fix=T, marg.shape.ind=1:2, marg.scale.ind=1:2,
                         marg.scale.start=fit2.4$mle[2:3], marg.shape.start=fit2.4$mle[4:5],
                         dep.start=fit2.4$mle[1],maxit=5000)
fit2.4











fit2.4.1<-fit.MGPD.GumbelU(x=Banks2, u=rep(0,2), std=F,
                           dep.scale.fix=T, dep.loc.fix=T, marg.shape.ind=1:2, marg.scale.ind=1:2,
                           marg.scale.start=fit2.4$mle[2:3], marg.shape.start=fit2.4$mle[4:5],
                           dep.start=fit2.4$mle[1],maxit=5000, hessian=T)





solve(fit2.4.1$hess)
sqrt(diag(solve(fit2.4.1$hess)))


###############################################################################################
# Comparison of VaR / ES of weighted sums from model versus univariate approach 

# VaR and ES (not including threshold sum(a*u))

VaR<-function(p,sig,gam,phi)
{
  if(abs(gam)>1e-6){return(sig*((p/phi)^(-gam)-1)/gam)}
  else{return(-sig*log(p/phi))}
}

ES<-function(p,sig,gam,phi)
{
  v<-VaR(p,sig,gam,phi)
  ES<-v+(sig+gam*v)/(1-gam)
  return(ES)
}

# VaR and ES (including threshold sum(a*u))

VaR2<-function(p,sig,gam,phi,th)
{
  if(abs(gam)>1e-6){return(sig*((p/phi)^(-gam)-1)/gam+th)}
  else{return(-sig*log(p/phi)+th)}
}

ES2<-function(p,sig,gam,phi,th)
{
  v<-VaR2(p,sig,gam,phi,th=th)
  ES<-v+(sig+gam*(v-th))/(1-gam)
  return(ES)
}

##################################################
# Exceedance probability

# (BSa defined below)
phi<-(dim(Banks2)[1]/dim(Banks)[1])*mean(BSa>0)
###########
# same as:
tmp<-apply(Banks,1,ws,a=a)
u<-apply(Banks,2,quantile,0.77)
mean(tmp-sum(a*u)>0)
###########



#############################################################################################
# Analysis with different portfolio weights
#############################################################################################

a<-c(50,50)
ws<-function(x,a){sum(a*x)}
BSa<-apply(Banks2,1,ws,a=a)
fitsuma<-gpd.fit(BSa,thresh=0)

# add in threshold
u<-apply(Banks,2,quantile,0.77)
sum(a*u)

# Re-definition exceedance probability
phi<-(dim(Banks2)[1]/dim(Banks)[1])*mean(BSa>0)



pseq<-seq(0.15,0.01,len=100)

VaRMV<-VaR2(p=pseq,sig=sum(a*fit2.4$mle[2:3]),gam=fit2.4$mle[4],phi=phi,th=sum(a*u))
VaRUV<-VaR2(p=pseq,sig=fitsuma$mle[1],gam=fitsuma$mle[2],phi=phi,th=sum(a*u))

pdf("VaRMV55.pdf") 
par(mar=c(5,5,4,2)) 

plot(-log(pseq), VaRMV, type="n", axes=F, xlab="p", ylab="VaR(p)", ylim=c(0,12), cex.lab=2)

axis(1,at=-log(c(0.15,0.1,0.01)),labels=(c(0.15,0.1,0.01)),cex.axis=2)
axis(2, at=c(0,2,4,6,8,10,12), cex.axis=2)
points(-log(phi*(length(BSa[BSa>0])+1-rank(BSa[BSa>0]))/(length(BSa[BSa>0])+1)), (BSa[BSa>0])+sum(a*u))
title("a=(50,50)", cex.main=2)

dev.off()  

ESMV<-ES2(p=pseq,sig=sum(a*fit2.4$mle[2:3]),gam=fit2.4$mle[4],phi=phi,th=sum(a*u))

Emp.ES<-NULL
BSa0<-BSa[BSa>0]
pseq2<-(1:length(BSa0))/(length(BSa0)+1)
Emp.ES<-cumsum(rev(sort(BSa0)))/(1:length(BSa0)) + sum(a*u)

pdf("ESMV55.pdf") 
par(mar=c(5,5,4,2)) 

plot(-log(pseq), VaRMV, type="n", axes=F, xlab="p", ylab="ES(p)", ylim=c(0,12), cex.lab=2)

axis(1,at=-log(c(0.15,0.1,0.01)),labels=(c(0.15,0.1,0.01)),cex.axis=2)
axis(2, at=c(0,2,4,6,8,10,12), cex.axis=2)
points(-log(pseq2*phi), Emp.ES)
title("a=(50,50)", cex.main=2)

dev.off() 

pdf("VaRMV551.pdf") 
par(mar=c(5,5,4,2)) 

plot(-log(pseq), VaRMV, type="l", axes=F, xlab="p", ylab="VaR(p)", ylim=c(0,30), cex.lab=2)

axis(1,at=-log(c(0.15,0.1,0.01)),labels=(c(0.15,0.1,0.01)),cex.axis=2)
axis(2, at=c(0,5,10,15,20,25,30), cex.axis=2)
points(-log(phi*(length(BSa[BSa>0])+1-rank(BSa[BSa>0]))/(length(BSa[BSa>0])+1)), (BSa[BSa>0])+sum(a*u))
title("a=(50,50)", cex.main=2)




a<-c(75,25)
ws<-function(x,a){sum(a*x)}
BSa<-apply(Banks2,1,ws,a=a)
fitsuma<-gpd.fit(BSa,thresh=0)

# add in threshold
u<-apply(Banks,2,quantile,0.77)
sum(a*u)

# Re-definition exceedance probability
phi<-(dim(Banks2)[1]/dim(Banks)[1])*mean(BSa>0)



pseq<-seq(0.15,0.01,len=100)

VaRMV<-VaR2(p=pseq,sig=sum(a*fit2.4$mle[2:3]),gam=fit2.4$mle[4],phi=phi,th=sum(a*u))
VaRUV<-VaR2(p=pseq,sig=fitsuma$mle[1],gam=fitsuma$mle[2],phi=phi,th=sum(a*u))

pdf("VaRMV75.pdf") 
par(mar=c(5,5,4,2)) 

plot(-log(pseq), VaRMV, type="n", axes=F, xlab="p", ylab="VaR(p)", ylim=c(0,12), cex.lab=2)

axis(1,at=-log(c(0.15,0.1,0.01)),labels=(c(0.15,0.1,0.01)),cex.axis=2)
axis(2, at=c(0,2,4,6,8,10,12), cex.axis=2)
points(-log(phi*(length(BSa[BSa>0])+1-rank(BSa[BSa>0]))/(length(BSa[BSa>0])+1)), (BSa[BSa>0])+sum(a*u))
title("a=(75,25)", cex.main=2)

dev.off()  

ESMV<-ES2(p=pseq,sig=sum(a*fit2.4$mle[2:3]),gam=fit2.4$mle[4],phi=phi,th=sum(a*u))

Emp.ES<-NULL
BSa0<-BSa[BSa>0]
pseq2<-(1:length(BSa0))/(length(BSa0)+1)
Emp.ES<-cumsum(rev(sort(BSa0)))/(1:length(BSa0)) + sum(a*u)

pdf("ESMV75.pdf") 
par(mar=c(5,5,4,2)) 

plot(-log(pseq), VaRMV, type="n", axes=F, xlab="p", ylab="ES(p)", ylim=c(0,12), cex.lab=2)

axis(1,at=-log(c(0.15,0.1,0.01)),labels=(c(0.15,0.1,0.01)),cex.axis=2)
axis(2, at=c(0,2,4,6,8,10,12), cex.axis=2)
points(-log(pseq2*phi), Emp.ES)
title("a=(75,25)", cex.main=2)

dev.off() 



a<-c(25,75)
ws<-function(x,a){sum(a*x)}
BSa<-apply(Banks2,1,ws,a=a)
fitsuma<-gpd.fit(BSa,thresh=0)

# add in threshold
u<-apply(Banks,2,quantile,0.77)
sum(a*u)

# Re-definition exceedance probability
phi<-(dim(Banks2)[1]/dim(Banks)[1])*mean(BSa>0)



pseq<-seq(0.15,0.01,len=100)

VaRMV<-VaR2(p=pseq,sig=sum(a*fit2.4$mle[2:3]),gam=fit2.4$mle[4],phi=phi,th=sum(a*u))
VaRUV<-VaR2(p=pseq,sig=fitsuma$mle[1],gam=fitsuma$mle[2],phi=phi,th=sum(a*u))

pdf("VaRMV25.pdf") 
par(mar=c(5,5,4,2)) 

plot(-log(pseq), VaRMV, type="n", axes=F, xlab="p", ylab="VaR(p)", ylim=c(0,12), cex.lab=2)

axis(1,at=-log(c(0.15,0.1,0.01)),labels=(c(0.15,0.1,0.01)),cex.axis=2)
axis(2, at=c(0,2,4,6,8,10,12), cex.axis=2)
points(-log(phi*(length(BSa[BSa>0])+1-rank(BSa[BSa>0]))/(length(BSa[BSa>0])+1)), (BSa[BSa>0])+sum(a*u))
title("a=(25,75)", cex.main=2)

dev.off()  

ESMV<-ES2(p=pseq,sig=sum(a*fit2.4$mle[2:3]),gam=fit2.4$mle[4],phi=phi,th=sum(a*u))

Emp.ES<-NULL
BSa0<-BSa[BSa>0]
pseq2<-(1:length(BSa0))/(length(BSa0)+1)
Emp.ES<-cumsum(rev(sort(BSa0)))/(1:length(BSa0)) + sum(a*u)

pdf("ESMV25.pdf") 
par(mar=c(5,5,4,2)) 

plot(-log(pseq), VaRMV, type="n", axes=F, xlab="p", ylab="ES(p)", ylim=c(0,12), cex.lab=2)

axis(1,at=-log(c(0.15,0.1,0.01)),labels=(c(0.15,0.1,0.01)),cex.axis=2)
axis(2, at=c(0,2,4,6,8,10,12), cex.axis=2)
points(-log(pseq2*phi), Emp.ES)
title("a=(25,75)", cex.main=2)

dev.off() 


# Marginal parameter stability plots to understand if 0.77 quantile might be OK
#################################################################################################

library(ismev)

plot(Banks[,1])
quantile(Banks[,1],0.77)
gpd.fitrange(Banks[,1],umin=0,umax=0.1,nint=20)
gpd.fit(Banks[,1],thresh=0.06)
m1<-gpd.fit(Banks[,1],thresh=quantile(Banks[,1],0.77))
gpd.diag(m1)

plot(Banks[,2])
quantile(Banks[,2],0.77)
gpd.fitrange(Banks[,2],umin=0,umax=0.2,nint=20)
gpd.fit(Banks[,2],thresh=0.06)
m2<-gpd.fit(Banks[,2],thresh=quantile(Banks[,2],0.77))
gpd.diag(m2)

# Compare marginal and jointly estimated standard errors

sqrt(diag(solve(fit2.4.1$hess)))[2]/m1$se[1]
sqrt(diag(solve(fit2.4.1$hess)))[3]/m2$se[1]
###############################################################################################
# Marginal GPD QQ plots
###############################################################################################
pdf("QQ.pdf",width=14,height=3.5)
GPD.diag.th(Banks2,sig=fit2.4$mle[2:3],gam=rep(fit2.4$mle[4],2))
dev.off()
