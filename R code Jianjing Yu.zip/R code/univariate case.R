library(ismev)
library(evd)
library(evgam)

data <- read.csv("C:/Users/BVBDo/Desktop/R code/HSBC.csv", header = TRUE, sep = ",")

y = data$Open

plot(y, type = "n")
lines(y)

z  <- 100 * diff(log(y))
plot(z, type = "n")
lines(z)

data = -z

library(evd)
mrlplot(data)
threshold <- quantile(data, 0.95)

tcplot(data,c(0,threshold))

fit <- fpot(data, threshold = 2.8)
plot(fit)

#nonstationary case here we assume there is a time dependence on the scale parameter

t <- c(1:523)

fit2 <- gpd.fit(xdat = data, 
                ydat = NULL, 
                sigl = NULL, threshold = 2.8)

fit3 <- gpd.fit(xdat = data, 
                ydat = cbind(t), 
                sigl = c(1), threshold = 2.8)


fit4 <- gpd.fit(xdat = data, 
                ydat = cbind(t, t^2), 
                sigl = c(1, 2), threshold = 2.8)

2 * (fit2$nllh - fit3$nllh)

2 * (fit3$nllh - fit4$nllh)

data <- data.frame(y = data, t = t)

exceed <- data$y - 2.8

ind <- which(exceed > 0)

fmla <- list(y ~ s(t, bs="cr"), ~ 1)

m_gpd <- evgam(fmla, data = data[ind, ], family="gpd")
gamsummary <- summary(m_gpd)
log_likelihood <- logLik(m_gpd)
print(log_likelihood)





